package com.Curd;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;

public class HibernateTest {

	public static void main(String[] args) {

		ProductDTO pd = new ProductDTO();

		pd.setId(1);
		pd.setName("Pan");
		pd.setPrice("5");

		SessionFactory sessionFactory = new Configuration().configure("com.Crud/Product.cfg.xml").buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(pd);
		tx.commit();
		session.close();

	}
}
